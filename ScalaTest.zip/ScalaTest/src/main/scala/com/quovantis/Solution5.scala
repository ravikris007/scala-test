package com.quovantis

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Solution5 {
     def main(args: Array[String]){
    
    val spark = SparkSession.builder()
                .appName("Total and Grade")
                .master("local[2]")
                .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
                
    val marksSrcDF = spark.read.option("inferSchema","true").option("header","true").csv("file:///C:\\input_data\\marks.csv")
    val studentSrcDF = spark.read.option("inferSchema","true").option("header","true").csv("file:///C:\\input_data\\student.csv")
    import spark.implicits._
    
    val df1 = studentSrcDF.join(marksSrcDF, 
        Seq("student_id")
        ,"inner")
    df1.printSchema()    

    val df2 = df1.select($"*",
        expr("case when english > 90 then 'A'"+ "when english between 80 and 90 then 'B'"+"when english between 70 and 79 then 'C' "+" when english between 60 and 69 then 'D'"+" when english between 50 and 59 then 'D' "+" when english between 40 and 40 then 'E'"+" else 'F' end").alias("english_grade"),
        expr("case when hindi > 90 then 'A'"+ "when hindi between 80 and 90 then 'B'"+"when hindi between 70 and 79 then 'C' "+" when hindi between 60 and 69 then 'D'"+" when hindi between 50 and 59 then 'D' "+" when hindi between 40 and 40 then 'E'"+" else 'F' end").alias("hindi_grade"),
        expr("case when maths > 90 then 'A'"+ "when maths between 80 and 90 then 'B'"+"when maths between 70 and 79 then 'C' "+" when maths between 60 and 69 then 'D'"+" when maths between 50 and 59 then 'D' "+" when maths between 40 and 40 then 'E'"+" else 'F' end").alias("maths_grade"),
        expr("case when science > 90 then 'A'"+ "when science between 80 and 90 then 'B'"+"when science between 70 and 79 then 'C' "+" when science between 60 and 69 then 'D'"+" when science between 50 and 59 then 'D' "+" when science between 40 and 40 then 'E'"+" else 'F' end").alias("science_grade")
        ,expr("english+hindi+maths+science").as("total_marks")
        )
    val df3 = df2.withColumn("pass_status",
        when(col("english_grade") =!= 'F' && col("hindi_grade") =!='F' && col("maths_grade") =!= 'F' && col("science_grade") =!= 'F', "P").otherwise("F"))
        
        
    val df4 = df3.filter($"pass_status" === "F" && $"class" === 5 and $"section" ==="C")
      .select($"name",$"class",$"section")
    
    //df4.printSchema()
    //df4.show
    df4.coalesce(1).write.mode("overwrite").option("header","true").csv("file:///C:\\output_data\\solution5")
  }
}