package com.quovantis

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Solution4 {
     def main(args: Array[String]){
    
    val spark = SparkSession.builder()
                .appName("Total and Grade")
                .master("local[2]")
                .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
                
    val marksSrcDF = spark.read.option("inferSchema","true").option("header","true").csv("file:///C:\\input_data\\marks.csv")
    val studentSrcDF = spark.read.option("inferSchema","true").option("header","true").csv("file:///C:\\input_data\\student.csv")
    import spark.implicits._
    
    val df1 = studentSrcDF.join(marksSrcDF, 
        Seq("student_id")
        ,"inner")
    df1.printSchema()    


    val df2 = df1.select($"name",$"class",$"section",
        expr("(english+hindi+maths+science)/4").as("average_percentage")
        )

    //df2.printSchema()
    //df2.show
    df2.coalesce(1).write.mode("overwrite").option("header","true").csv("file:///C:\\output_data\\solution4")
  }
}